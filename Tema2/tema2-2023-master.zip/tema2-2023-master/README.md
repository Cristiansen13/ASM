# Perfect assignment

Write a program that given a number as input argument prints the corespondig number of 1s on standard output.

E.g:
```bash
$> ./binary 3
1 1 1
```
